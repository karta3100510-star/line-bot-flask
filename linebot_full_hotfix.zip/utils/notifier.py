# utils/notifier.py
# 最小可運行版本：讀入你分析結果(若有)並推播（目前只記錄log示意）
import logging
from datetime import datetime

def send_daily_summary():
    logging.info("[notifier] send_daily_summary at %s", datetime.utcnow().isoformat()+"Z")
    # TODO: 讀 data/analysis.json，呼叫 LINE Push API 向訂閱者推播
