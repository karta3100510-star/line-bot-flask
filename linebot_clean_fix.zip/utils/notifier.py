# utils/notifier.py
import logging
from datetime import datetime

def send_daily_summary():
    logging.info("[notifier] send_daily_summary at %s", datetime.utcnow().isoformat()+"Z")
