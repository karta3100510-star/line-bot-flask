# LINE Bot 一鍵分析（乾淨熱修復版）

此版本**不含**舊的 `utils/scheduler.py`，僅使用 `utils/scheduler_fix.py`，避免 import 時觸發 NameError。

## 指令與端點
- `/quote <TICKER>`：回覆技術＋基本面＋新聞＋機構評分＋建議價位
- `GET /healthz`：健康檢查
- `GET /debug`：顯示正在使用的 scheduler 模組與版本

## 安裝與部署（Render）
1. 設定環境變數：`LINE_CHANNEL_SECRET`、`LINE_CHANNEL_ACCESS_TOKEN`（必要）；`FINNHUB_TOKEN` / `ALPHAVANTAGE_KEY`（擇一或都填）。
2. 部署：使用 `render.yaml`，Start Command 為 `python -m gunicorn app:app`。
3. **務必刪除專案內任何舊的 `utils/scheduler.py`**（如果你的 repo 裡有，請直接刪掉或改名）。
4. 在 Render → Deploys → **Clear build cache** 後再 Deploy。

## 驗證
部署後打 `GET /debug`，應看到：
```
module: utils.scheduler_fix
file: /opt/render/project/src/utils/scheduler_fix.py
version: 2025-09-22.clean
tz: Asia/Taipei
```

## 檔案一覽
- `app.py`：整合 `/quote`、`/healthz`、`/debug`，並啟動 `scheduler_fix`
- `analysis_pipeline.py`：技術/基本面/新聞/機構評分/綜合建議
- `analyzer.py`（stub）：提供 `analyze_data()`，供排程呼叫
- `utils/scheduler_fix.py`：安全 Scheduler，不在 import 時排程
- `utils/notifier.py`（stub）：提供 `send_daily_summary()`
- 其它：`requirements.txt`、`Procfile`、`runtime.txt`、`render.yaml`、`.env.example`
